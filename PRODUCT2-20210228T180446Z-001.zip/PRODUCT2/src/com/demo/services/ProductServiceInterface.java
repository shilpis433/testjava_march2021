package com.demo.services;

import com.demo.bean.Product;

public interface ProductServiceInterface {

	Product[] displaybycategory(int ch);

	void acceptdata(int ch);

	void displayall();

	Product displayById(int id);

	float calculateGST(int id);
	
}
