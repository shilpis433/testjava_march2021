package com.demo.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.demo.bean.Nonperishable;
import com.demo.bean.Perishable;
import com.demo.bean.Product;

public class ProductService implements ProductServiceInterface {
	private static Product[] parr;
	 static SimpleDateFormat sdf;
	 static int count,pcount,ncount;
	 
	  static {
		  sdf=new SimpleDateFormat("dd/MM/yyyy");
		  parr=new Product[100];
		  count=0;
		  pcount=0;
		  ncount=0;
     }
	  
	 //function for accepting data from client
	 public void acceptdata(int ch) {
		 Scanner ob=new Scanner(System.in);
		 System.out.println("Please enter the name of the product");
		 String name=ob.next();
		 System.out.println("PLease enter the price");
		 float price=ob.nextFloat();
		 System.out.println("Please enter the manufactured date of the product in dd/mm/yyyy");
		 String date=ob.next();
		 Date mfgdate=null;
		 try {
			 mfgdate=sdf.parse(date);
		 }
		 catch(ParseException e){
			 e.printStackTrace();
		 }
		 String type;
		 if(ch==1) {
			 	type="Perishable";
			 	System.out.println("Please enter the expiry date in dd/mm/yyyy format");
			 	String date1=ob.next();
			 	Date expdate=null;
				try {
					expdate=sdf.parse(date1);
					} 
				catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
				parr[count]=new Perishable(name,price,type,mfgdate,expdate);
				pcount++;
		 	}
		 else {
			 type="Non-Perishable";
			 System.out.println("Please enter the category");
			 	String category=ob.next();
				parr[count]=new Nonperishable(name,price,type,mfgdate,category);
				ncount++;
		 }
		 count++;
	 }
	 
	//function to display data by category to the client
	public Product[] displaybycategory(int ch) {
			
			int cnt=0;
			switch(ch) 
			{
			case 1:	Product[] perish=new Product[pcount];
					for(int i=0;i<count;i++) {
					if(parr[i] instanceof Perishable) {
						perish[cnt]=parr[i];
						cnt++;
						}
					}
					if(perish.length==0)
						return null;
					else
						return perish;		
			case 2: Product[] nonperish=new Product[ncount];
					for(int i=0;i<count;i++) {
					if(parr[i] instanceof Nonperishable) {
						nonperish[cnt]=parr[i];
						cnt++;
						}
					}
					if(nonperish.length==0)
						return null;
					else
						return nonperish;		
				
			}
			return null;
			
	}

	//function to display all data
	public void displayall() {
		for(int i=0;i<count;i++)
		{
			System.out.println(parr[i]);
		}
		
		
	}

	//function to display by the id of the data;
	@Override
	public Product displayById(int id) {
		for(int i=0;i<count;i++) {
			if(parr[i].getId()==id) {
				return parr[i];
			}
		}
		return null;
	}

	
	public float calculateGST(int id) {
		Product P=displayById(id);
		if(P instanceof Perishable) {
			return P.getPrice()*0.05f;
		}
		else if(P instanceof Nonperishable){
			return 100+(P.getPrice()*0.15f);
		}
		else {
			return 0.0f;
		}
		
	}


	
	
	
	
}
