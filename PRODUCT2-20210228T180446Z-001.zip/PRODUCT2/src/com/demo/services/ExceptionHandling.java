package com.demo.services;

import java.util.Scanner;

public class ExceptionHandling {
	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=45;
        while(true)
        {
            try {
            
            System.out.println("enter the number");
            int num=sc.nextInt();
            if(num!=n) {
                throw new ArithmeticException("Oops, you onr life");
            }
            else {
                System.out.println("Yepeee!! your guess is right");
                break;
            }
            }catch(ArithmeticException e) {
                System.out.println(e.getMessage());
            }
        }
	}
}
    
