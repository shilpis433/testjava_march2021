package com.demo.bean;

import java.util.Date;

public class Product {
	
	private static int count;
	static {
		count=1;
	}
	
	private int id;
	private String name;
	private float price;
	private String type;
	private Date mfgdate;
	
	
	public Product() {
		super();
	}


	public Product(String name, float price, String type,Date mfgdate) {
		super();
		this.id = count++;
		this.name = name;
		this.price = price;
		this.type = type;
		this.mfgdate=mfgdate;
	}


	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	public  float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}
	
	public Date getmfgdate() {
		return mfgdate;
	}
	
	public void setmfgdate(Date mfgdate) {
		this.mfgdate=mfgdate;
	}


	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", type=" + type + ", mfgdate=" + mfgdate
				+ "]";
	}
	
	

}
