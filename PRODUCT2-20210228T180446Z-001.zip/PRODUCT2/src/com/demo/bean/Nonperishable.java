package com.demo.bean;

import java.util.Date;

public class Nonperishable extends Product {
	private String category;;

	
	
	public Nonperishable() {
		super();
	}


	public Nonperishable(String name,float price,String type,Date mfgdate,String category) {
		super(name,price,type,mfgdate);
		this.category = category;
	}


	public String getcategory() {
		return category;
	}


	public void setcategory(String category) {
		this.category = category;
	}


	@Override
	public String toString() {
		return super.toString()+"Nonperishable [category=" + category + "]";
	}


	
	
	
}
