package com.demo.bean;

import java.util.Date;

import com.demo.services.*;

public class Perishable extends Product {
	private Date Expdate;
	
	ProductServiceInterface ob1=new ProductService(); 

	public Perishable() {
		super();
	}

	public Perishable(String name, float price,String type,Date mfgdate,Date expdate) {
		super(name,price,type,mfgdate);
		Expdate = expdate;
	}

	public Date getExpdate() {
		return Expdate;
	}

	public void setExpdate(Date expdate) {
		Expdate = expdate;
	}
	
	public float calculate(int id) {
		Product s=ob1.displayById(id);
		return s.getPrice()+(s.getPrice()*0.18f);
	}
	
	@Override
	public String toString() {
		return super.toString()+"Perishable [Expdate=" + Expdate + "]";
	}
	
	/*public static double calculateGST(int id) {
		return Product.getPrice()+ getPrice()*0.18;
	}*/

	
	
}
