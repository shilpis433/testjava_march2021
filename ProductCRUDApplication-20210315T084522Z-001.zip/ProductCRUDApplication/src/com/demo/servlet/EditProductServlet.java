package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.model.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

/**
 * Servlet implementation class EditProductServlet
 */
@WebServlet("/editProd")
public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
private ProductService ps;
	
	public void init() {
		ps=new ProductServiceImpl();
	}	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		int pid=Integer.parseInt(request.getParameter("pid"));
		Product p=ps.getById(pid);
		
		if(p!=null) {
			out.println("<form action='/ProductCRUDApplication/updateProd'>");
			out.println("Product Id : <input type='hidden' name='pid' value='"+p.getPid()+"'>");
			out.println("Product Name : <input type='text' name='pname' value='"+p.getPname()+"'>");
			out.println("Product Quantity : <input type='number' name='qty' value='"+p.getQty()+"'>");
			out.println("Product Price : <input type='text' name='price' value='"+p.getPrice()+"'>");
			out.println("Category Id : <input type='text' name='cid' value='"+p.getCid()+"'>");
			out.println("<input type='submit' name='btn' value='Update Product'>");
		    out.println("</form>");
			
		}
	}

	

}
