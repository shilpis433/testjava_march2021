package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.model.MyUSer;

public class LoginDaoImpl implements LoginDao {
	private static Connection conn;
	private static PreparedStatement pcheklogin;
	static {
		conn=DBUtil.getMyConnection();
		try {
			pcheklogin=conn.prepareStatement("select * from MyUser where uname=? and pass=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public MyUSer checkLogin(String unm, String pass) {
		try {
			pcheklogin.setString(1,unm);
			pcheklogin.setString(2, pass);
			ResultSet rs=pcheklogin.executeQuery();
			if(rs.next()) {
				MyUSer u=new MyUSer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				return u;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
