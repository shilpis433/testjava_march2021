package com.demo.dao;

import java.util.List;

import com.demo.model.Product;

public interface ProductDao {

	List<Product> findAllProduct();

	int addProduct(Product p);

	Product findById(int pid);

	int updateProduct(Product p);

	int deleteProduct(int pid);

}
