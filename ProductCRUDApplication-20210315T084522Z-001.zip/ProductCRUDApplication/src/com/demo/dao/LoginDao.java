package com.demo.dao;

import com.demo.model.MyUSer;

public interface LoginDao {

	MyUSer checkLogin(String unm, String pass);

}
