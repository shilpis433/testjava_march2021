package com.demo.service;

import java.util.List;

import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;
import com.demo.model.Product;

public class ProductServiceImpl implements ProductService{
	private ProductDao pDao;
	

	public ProductServiceImpl() {
		super();
		this.pDao = new ProductDaoImpl();
	}


	@Override
	public List<Product> getAllProduct() {
		
		return pDao.findAllProduct();
	}


	@Override
	public int addNewProduct(Product p) {
		return pDao.addProduct(p);
	}


	@Override
	public Product getById(int pid) {
		return pDao.findById(pid);
	}


	@Override
	public int updateProduct(Product p) {
		return pDao.updateProduct(p);
	}


	@Override
	public int deleteProduct(int pid) {
		return pDao.deleteProduct(pid);
	}

}
