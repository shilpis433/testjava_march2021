package com.demo.service;

import java.util.List;

import com.demo.model.Product;

public interface ProductService {

	List<Product> getAllProduct();

	int addNewProduct(Product p);

	Product getById(int pid);

	int updateProduct(Product p);

	int deleteProduct(int pid);

}
