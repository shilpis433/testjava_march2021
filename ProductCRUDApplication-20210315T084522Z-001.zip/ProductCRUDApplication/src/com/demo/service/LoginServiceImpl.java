package com.demo.service;

import com.demo.dao.LoginDao;
import com.demo.dao.LoginDaoImpl;
import com.demo.model.MyUSer;

public class LoginServiceImpl implements LoginService{
      private LoginDao lDao;
      
	public LoginServiceImpl() {
		super();
		this.lDao = new LoginDaoImpl();
	}

	@Override
	public MyUSer checkLogin(String unm, String pass) {
		return lDao.checkLogin(unm,pass);
	}

}
