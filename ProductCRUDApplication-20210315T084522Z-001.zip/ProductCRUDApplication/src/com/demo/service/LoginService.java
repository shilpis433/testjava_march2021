package com.demo.service;

import com.demo.model.MyUSer;

public interface LoginService {

	MyUSer checkLogin(String unm, String pass);

}
